<?php
include "conexion.php";
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Estudiantes</title>
</head>
<body>

<h2>Gestion de Estudiantes</h2>

<h3>Guardar estudiante</h3>

<form id="formGuardar">
    Estudiante:
    <input type="text" name="nombreEstudiante" required>

    Edad:
    <input type="number" name="edad" required>

    Materia:
    <select name="idMateria">
        <?php
        $sql = "SELECT idMateria, nombreMateria FROM materia";
        $resultado = $conexion->query($sql);

        while ($fila = $resultado->fetch_assoc()) {
            echo "<option value='".$fila["idMateria"]."'>".$fila["nombreMateria"]."</option>";
        }
        ?>
    </select>

    <button type="submit">Guardar</button>
</form>

<p id="mensaje"></p>

<hr>

<h3>Listar estudiantes por materia</h3>

Materia:
<select id="materiaBuscar">
    <?php
    $sql = "SELECT idMateria, nombreMateria FROM materia";
    $resultado = $conexion->query($sql);

    while ($fila = $resultado->fetch_assoc()) {
        echo "<option value='".$fila["idMateria"]."'>".$fila["nombreMateria"]."</option>";
    }
    ?>
</select>

<button onclick="listar()">Listar</button>

<br><br>

<div id="resultado"></div>

<script>
document.getElementById("formGuardar").addEventListener("submit", function(e) {
    e.preventDefault();

    let datos = new FormData(this);

    fetch("guardar.php", {
        method: "POST",
        body: datos
    })
    .then(res => res.text())
    .then(data => {
        document.getElementById("mensaje").innerHTML = data;
        document.getElementById("formGuardar").reset();
    });
});

function listar() {
    let idMateria = document.getElementById("materiaBuscar").value;

    fetch("listar.php?idMateria=" + idMateria)
    .then(res => res.text())
    .then(data => {
        document.getElementById("resultado").innerHTML = data;
    });
}
</script>

</body>
</html>

