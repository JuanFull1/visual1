<?php
include "conexion.php";

$nombreEstudiante = $_POST["nombreEstudiante"];
$edad = $_POST["edad"];
$idMateria = $_POST["idMateria"];

if ($idMateria == 1 || $idMateria == 2 || $idMateria == 3) {
    $sql = "INSERT INTO estudiante(nombreEstudiante, edad, idMateria)
            VALUES('$nombreEstudiante', '$edad', '$idMateria')";

    if ($conexion->query($sql)) {
        echo "Estudiante guardado correctamente";
    } else {
        echo "Error al guardar";
    }
} else {
    echo "Materia no permitida";
}
?>