<?php

$conexion = new mysqli("localhost", "root", "", "estudiantes_db");

if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

?>