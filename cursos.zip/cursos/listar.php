<?php
include "conexion.php";

$idMateria = $_GET["idMateria"];

$sql = "SELECT e.idEstudiante, e.nombreEstudiante, e.edad, m.nombreMateria
        FROM estudiante e
        INNER JOIN materia m ON e.idMateria = m.idMateria
        WHERE e.idMateria = $idMateria";

$resultado = $conexion->query($sql);

echo "<table border='1' cellpadding='8'>";
echo "<tr><th>ID</th><th>Estudiante</th><th>Edad</th><th>Materia</th></tr>";

while ($fila = $resultado->fetch_assoc()) {
    echo "<tr>";
    echo "<td>".$fila["idEstudiante"]."</td>";
    echo "<td>".$fila["nombreEstudiante"]."</td>";
    echo "<td>".$fila["edad"]."</td>";
    echo "<td>".$fila["nombreMateria"]."</td>";
    echo "</tr>";
}

echo "</table>";
?>





















/*

DROP DATABASE IF EXISTS estudiantes_db;
CREATE DATABASE estudiantes_db;
USE estudiantes_db;

CREATE TABLE materia (
    idMateria INT AUTO_INCREMENT PRIMARY KEY,
    nombreMateria VARCHAR(50) NOT NULL UNIQUE
);

INSERT INTO materia (nombreMateria) VALUES
('matematicas'),
('lenguaje'),
('programacion');

CREATE TABLE estudiante (
    idEstudiante INT AUTO_INCREMENT PRIMARY KEY,
    nombreEstudiante VARCHAR(100) NOT NULL,
    edad INT NOT NULL,
    idMateria INT NOT NULL,
    FOREIGN KEY (idMateria) REFERENCES materia(idMateria)
);

INSERT INTO estudiante (nombreEstudiante, edad, idMateria) VALUES
('Juan Perez', 18, 1),
('Maria Lopez', 19, 1),
('Carlos Vera', 20, 2),
('Ana Torres', 18, 2),
('Luis Gomez', 21, 3),
('Diana Ruiz', 20, 3);

*/